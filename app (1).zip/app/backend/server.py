from fastapi import FastAPI, APIRouter, HTTPException, UploadFile, File, Form, Depends, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import bcrypt
import jwt
import base64
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
from emergentintegrations.llm.chat import LlmChat, UserMessage
from emergentintegrations.llm.gemeni.image_generation import GeminiImageGeneration

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT and API Keys
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key')
JWT_ALGORITHM = 'HS256'
EMERGENT_LLM_KEY = os.environ['EMERGENT_LLM_KEY']

# Initialize AI services
image_gen = GeminiImageGeneration(api_key=EMERGENT_LLM_KEY)

app = FastAPI()
api_router = APIRouter(prefix="/api")
security = HTTPBearer()

# ============== MODELS ==============

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    username: str
    email: EmailStr
    full_name: str = ""
    bio: str = ""
    website: str = ""
    profile_image: str = ""
    password_hash: str = ""
    is_private: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str
    full_name: str = ""

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class GoogleAuthData(BaseModel):
    google_id: str
    email: EmailStr
    full_name: str
    username: str
    profile_image: str = ""

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    bio: Optional[str] = None
    website: Optional[str] = None
    profile_image: Optional[str] = None
    is_private: Optional[bool] = None

class Project(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    username: str
    title: str
    description: str = ""
    category: str = ""
    hashtags: List[str] = []
    file_data: str  # base64 encoded
    file_type: str
    is_public: bool = True
    likes_count: int = 0
    comments_count: int = 0
    views_count: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProjectCreate(BaseModel):
    title: str
    description: Optional[str] = ""
    category: Optional[str] = ""
    hashtags: Optional[List[str]] = []
    is_public: bool = True

class ProjectUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    is_public: Optional[bool] = None

class Follow(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    follower_id: str
    following_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Like(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    project_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Comment(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    user_id: str
    username: str
    text: str
    parent_comment_id: Optional[str] = None
    likes_count: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CommentCreate(BaseModel):
    text: str
    parent_comment_id: Optional[str] = None

class SavedPost(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    project_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Message(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    sender_id: str
    receiver_id: str
    content: str
    content_type: str = "text"  # text, image, video, link
    is_read: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class MessageCreate(BaseModel):
    receiver_id: str
    content: str
    content_type: str = "text"

class Notification(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    actor_id: str
    actor_username: str
    actor_profile_image: str
    type: str  # follow, like, comment
    project_id: Optional[str] = None
    is_read: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class GeneratedImage(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    prompt: str
    image_data: str  # base64 encoded
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ImageGenerateRequest(BaseModel):
    prompt: str

class AIAssistantMessage(BaseModel):
    message: str

# ============== HELPER FUNCTIONS ==============

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(user_id: str) -> str:
    expiration = datetime.now(timezone.utc) + timedelta(days=30)
    return jwt.encode(
        {"user_id": user_id, "exp": expiration},
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        token = credentials.credentials
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("user_id")
        user = await db.users.find_one({"id": user_id}, {"_id": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except Exception as e:
        raise HTTPException(status_code=401, detail="Invalid authentication")

async def create_notification(user_id: str, actor_id: str, notif_type: str, project_id: Optional[str] = None):
    actor = await db.users.find_one({"id": actor_id}, {"_id": 0})
    if not actor or actor_id == user_id:
        return
    
    notification = Notification(
        user_id=user_id,
        actor_id=actor_id,
        actor_username=actor["username"],
        actor_profile_image=actor.get("profile_image", ""),
        type=notif_type,
        project_id=project_id
    )
    doc = notification.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.notifications.insert_one(doc)

def add_watermark(image_bytes: bytes) -> str:
    """Add watermark to image and return base64"""
    img = Image.open(BytesIO(image_bytes))
    
    if img.mode != 'RGBA':
        img = img.convert('RGBA')
    
    txt_layer = Image.new('RGBA', img.size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(txt_layer)
    
    text = "Made with Design's"
    font_size = max(20, img.width // 40)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
    except:
        font = ImageFont.load_default()
    
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    x = img.width - text_width - 20
    y = img.height - text_height - 20
    
    draw.text((x, y), text, fill=(255, 255, 255, 180), font=font)
    
    watermarked = Image.alpha_composite(img, txt_layer)
    watermarked = watermarked.convert('RGB')
    
    buffer = BytesIO()
    watermarked.save(buffer, format='PNG')
    return base64.b64encode(buffer.getvalue()).decode('utf-8')

# ============== AUTH ROUTES ==============

@api_router.post("/auth/register")
async def register(user_data: UserCreate):
    # Check if username exists
    existing_user = await db.users.find_one({"username": user_data.username}, {"_id": 0})
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already exists")
    
    # Check if email exists
    existing_email = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing_email:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user = User(
        username=user_data.username,
        email=user_data.email,
        full_name=user_data.full_name,
        password_hash=hash_password(user_data.password)
    )
    
    doc = user.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.users.insert_one(doc)
    
    token = create_token(user.id)
    return {"token": token, "user": {k: v for k, v in user.model_dump().items() if k != 'password_hash'}}

@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    user = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user or not verify_password(credentials.password, user['password_hash']):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    token = create_token(user['id'])
    return {"token": token, "user": {k: v for k, v in user.items() if k != 'password_hash'}}

@api_router.post("/auth/google")
async def google_auth(auth_data: GoogleAuthData):
    # Check if user exists by email
    user = await db.users.find_one({"email": auth_data.email}, {"_id": 0})
    
    if user:
        token = create_token(user['id'])
        return {"token": token, "user": {k: v for k, v in user.items() if k != 'password_hash'}}
    
    # Check if username exists
    existing_username = await db.users.find_one({"username": auth_data.username}, {"_id": 0})
    if existing_username:
        raise HTTPException(status_code=400, detail="Username already exists")
    
    # Create new user
    new_user = User(
        username=auth_data.username,
        email=auth_data.email,
        full_name=auth_data.full_name,
        profile_image=auth_data.profile_image,
        password_hash=hash_password(auth_data.google_id)
    )
    
    doc = new_user.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.users.insert_one(doc)
    
    token = create_token(new_user.id)
    return {"token": token, "user": {k: v for k, v in new_user.model_dump().items() if k != 'password_hash'}}

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    return {k: v for k, v in current_user.items() if k != 'password_hash'}

# ============== USER ROUTES ==============

@api_router.get("/users/search")
async def search_users(q: str):
    users = await db.users.find(
        {"username": {"$regex": q, "$options": "i"}},
        {"_id": 0, "password_hash": 0}
    ).to_list(20)
    return users

@api_router.get("/users/{username}")
async def get_user_profile(username: str):
    user = await db.users.find_one({"username": username}, {"_id": 0, "password_hash": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Get stats
    followers_count = await db.follows.count_documents({"following_id": user['id']})
    following_count = await db.follows.count_documents({"follower_id": user['id']})
    projects_count = await db.projects.count_documents({"user_id": user['id'], "is_public": True})
    
    user['followers_count'] = followers_count
    user['following_count'] = following_count
    user['projects_count'] = projects_count
    
    return user

@api_router.put("/users/profile")
async def update_profile(update_data: UserUpdate, current_user: dict = Depends(get_current_user)):
    update_dict = {k: v for k, v in update_data.model_dump().items() if v is not None}
    
    if update_dict:
        await db.users.update_one({"id": current_user['id']}, {"$set": update_dict})
    
    updated_user = await db.users.find_one({"id": current_user['id']}, {"_id": 0, "password_hash": 0})
    return updated_user

# ============== PROJECT ROUTES ==============

@api_router.post("/projects")
async def create_project(
    title: str = Form(...),
    description: str = Form(""),
    category: str = Form(""),
    is_public: bool = Form(True),
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    # Validate file type
    allowed_types = ['cdr', 'psd', 'ai', 'jpg', 'jpeg', 'png']
    file_ext = file.filename.split('.')[-1].lower()
    if file_ext not in allowed_types:
        raise HTTPException(status_code=400, detail="Invalid file type")
    
    # Read and encode file
    file_content = await file.read()
    file_data = base64.b64encode(file_content).decode('utf-8')
    
    project = Project(
        user_id=current_user['id'],
        username=current_user['username'],
        title=title,
        description=description,
        category=category,
        file_data=file_data,
        file_type=file_ext,
        is_public=is_public
    )
    
    doc = project.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.projects.insert_one(doc)
    
    return project

@api_router.get("/projects/explore")
async def get_explore_projects(skip: int = 0, limit: int = 30):
    projects = await db.projects.find(
        {"is_public": True},
        {"_id": 0}
    ).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)
    
    for project in projects:
        if isinstance(project.get('created_at'), str):
            project['created_at'] = datetime.fromisoformat(project['created_at'])
    
    return projects

@api_router.get("/projects/search")
async def search_projects(q: str):
    projects = await db.projects.find(
        {
            "is_public": True,
            "$or": [
                {"title": {"$regex": q, "$options": "i"}},
                {"category": {"$regex": q, "$options": "i"}}
            ]
        },
        {"_id": 0}
    ).to_list(30)
    return projects

@api_router.get("/projects/user/{username}")
async def get_user_projects(username: str):
    user = await db.users.find_one({"username": username}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    projects = await db.projects.find(
        {"user_id": user['id'], "is_public": True},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    return projects

@api_router.get("/projects/{project_id}")
async def get_project(project_id: str):
    project = await db.projects.find_one({"id": project_id}, {"_id": 0})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Increment view count
    await db.projects.update_one({"id": project_id}, {"$inc": {"views_count": 1}})
    project['views_count'] = project.get('views_count', 0) + 1
    
    return project

@api_router.put("/projects/{project_id}")
async def update_project(
    project_id: str,
    update_data: ProjectUpdate,
    current_user: dict = Depends(get_current_user)
):
    project = await db.projects.find_one({"id": project_id}, {"_id": 0})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    if project['user_id'] != current_user['id']:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    update_dict = {k: v for k, v in update_data.model_dump().items() if v is not None}
    if update_dict:
        await db.projects.update_one({"id": project_id}, {"$set": update_dict})
    
    updated_project = await db.projects.find_one({"id": project_id}, {"_id": 0})
    return updated_project

@api_router.delete("/projects/{project_id}")
async def delete_project(project_id: str, current_user: dict = Depends(get_current_user)):
    project = await db.projects.find_one({"id": project_id}, {"_id": 0})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    if project['user_id'] != current_user['id']:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    await db.projects.delete_one({"id": project_id})
    return {"message": "Project deleted"}

@api_router.post("/projects/generate-description")
async def generate_description(title: str = Form(...), current_user: dict = Depends(get_current_user)):
    """Generate AI description and hashtags for a project"""
    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=f"desc_gen_{current_user['id']}",
        system_message="You are a creative designer assistant. Generate engaging descriptions and relevant hashtags for design projects."
    ).with_model("openai", "gpt-5")
    
    user_message = UserMessage(
        text=f"Create a short, engaging description (2-3 sentences) and 5 relevant hashtags for a design project titled '{title}'. Format: Description: [description]\nHashtags: [hashtag1, hashtag2, etc]"
    )
    
    response = await chat.send_message(user_message)
    
    # Parse response
    lines = response.strip().split('\n')
    description = ""
    hashtags = []
    
    for line in lines:
        if line.startswith('Description:'):
            description = line.replace('Description:', '').strip()
        elif line.startswith('Hashtags:'):
            hashtag_str = line.replace('Hashtags:', '').strip()
            hashtags = [h.strip('#, ') for h in hashtag_str.split(',')]
    
    return {"description": description, "hashtags": hashtags}

# ============== SOCIAL FEATURES ==============

@api_router.post("/follow/{user_id}")
async def follow_user(user_id: str, current_user: dict = Depends(get_current_user)):
    if user_id == current_user['id']:
        raise HTTPException(status_code=400, detail="Cannot follow yourself")
    
    existing = await db.follows.find_one(
        {"follower_id": current_user['id'], "following_id": user_id},
        {"_id": 0}
    )
    if existing:
        raise HTTPException(status_code=400, detail="Already following")
    
    follow = Follow(follower_id=current_user['id'], following_id=user_id)
    doc = follow.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.follows.insert_one(doc)
    
    await create_notification(user_id, current_user['id'], "follow")
    
    return {"message": "Followed successfully"}

@api_router.delete("/follow/{user_id}")
async def unfollow_user(user_id: str, current_user: dict = Depends(get_current_user)):
    result = await db.follows.delete_one(
        {"follower_id": current_user['id'], "following_id": user_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Not following this user")
    
    return {"message": "Unfollowed successfully"}

@api_router.get("/follow/status/{user_id}")
async def get_follow_status(user_id: str, current_user: dict = Depends(get_current_user)):
    is_following = await db.follows.find_one(
        {"follower_id": current_user['id'], "following_id": user_id},
        {"_id": 0}
    )
    return {"is_following": bool(is_following)}

@api_router.get("/followers/{user_id}")
async def get_followers(user_id: str):
    follows = await db.follows.find({"following_id": user_id}, {"_id": 0}).to_list(1000)
    follower_ids = [f['follower_id'] for f in follows]
    
    users = await db.users.find(
        {"id": {"$in": follower_ids}},
        {"_id": 0, "password_hash": 0}
    ).to_list(1000)
    return users

@api_router.get("/following/{user_id}")
async def get_following(user_id: str):
    follows = await db.follows.find({"follower_id": user_id}, {"_id": 0}).to_list(1000)
    following_ids = [f['following_id'] for f in follows]
    
    users = await db.users.find(
        {"id": {"$in": following_ids}},
        {"_id": 0, "password_hash": 0}
    ).to_list(1000)
    return users

# ============== LIKES ==============

@api_router.post("/likes/{project_id}")
async def like_project(project_id: str, current_user: dict = Depends(get_current_user)):
    existing = await db.likes.find_one(
        {"user_id": current_user['id'], "project_id": project_id},
        {"_id": 0}
    )
    if existing:
        raise HTTPException(status_code=400, detail="Already liked")
    
    like = Like(user_id=current_user['id'], project_id=project_id)
    doc = like.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.likes.insert_one(doc)
    
    await db.projects.update_one({"id": project_id}, {"$inc": {"likes_count": 1}})
    
    project = await db.projects.find_one({"id": project_id}, {"_id": 0})
    if project:
        await create_notification(project['user_id'], current_user['id'], "like", project_id)
    
    return {"message": "Liked successfully"}

@api_router.delete("/likes/{project_id}")
async def unlike_project(project_id: str, current_user: dict = Depends(get_current_user)):
    result = await db.likes.delete_one(
        {"user_id": current_user['id'], "project_id": project_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Not liked")
    
    await db.projects.update_one({"id": project_id}, {"$inc": {"likes_count": -1}})
    return {"message": "Unliked successfully"}

@api_router.get("/likes/status/{project_id}")
async def get_like_status(project_id: str, current_user: dict = Depends(get_current_user)):
    is_liked = await db.likes.find_one(
        {"user_id": current_user['id'], "project_id": project_id},
        {"_id": 0}
    )
    return {"is_liked": bool(is_liked)}

@api_router.get("/likes/user")
async def get_user_liked_projects(current_user: dict = Depends(get_current_user)):
    likes = await db.likes.find({"user_id": current_user['id']}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    project_ids = [like['project_id'] for like in likes]
    
    projects = await db.projects.find({"id": {"$in": project_ids}}, {"_id": 0}).to_list(1000)
    return projects

# ============== COMMENTS ==============

@api_router.post("/comments/{project_id}")
async def create_comment(
    project_id: str,
    comment_data: CommentCreate,
    current_user: dict = Depends(get_current_user)
):
    comment = Comment(
        project_id=project_id,
        user_id=current_user['id'],
        username=current_user['username'],
        text=comment_data.text,
        parent_comment_id=comment_data.parent_comment_id
    )
    
    doc = comment.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.comments.insert_one(doc)
    
    await db.projects.update_one({"id": project_id}, {"$inc": {"comments_count": 1}})
    
    project = await db.projects.find_one({"id": project_id}, {"_id": 0})
    if project:
        await create_notification(project['user_id'], current_user['id'], "comment", project_id)
    
    return comment

@api_router.get("/comments/{project_id}")
async def get_comments(project_id: str):
    comments = await db.comments.find(
        {"project_id": project_id},
        {"_id": 0}
    ).sort("created_at", -1).to_list(1000)
    return comments

# ============== SAVED POSTS ==============

@api_router.post("/saved/{project_id}")
async def save_project(project_id: str, current_user: dict = Depends(get_current_user)):
    existing = await db.saved_posts.find_one(
        {"user_id": current_user['id'], "project_id": project_id},
        {"_id": 0}
    )
    if existing:
        raise HTTPException(status_code=400, detail="Already saved")
    
    saved = SavedPost(user_id=current_user['id'], project_id=project_id)
    doc = saved.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.saved_posts.insert_one(doc)
    
    return {"message": "Saved successfully"}

@api_router.delete("/saved/{project_id}")
async def unsave_project(project_id: str, current_user: dict = Depends(get_current_user)):
    result = await db.saved_posts.delete_one(
        {"user_id": current_user['id'], "project_id": project_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Not saved")
    
    return {"message": "Unsaved successfully"}

@api_router.get("/saved/status/{project_id}")
async def get_saved_status(project_id: str, current_user: dict = Depends(get_current_user)):
    is_saved = await db.saved_posts.find_one(
        {"user_id": current_user['id'], "project_id": project_id},
        {"_id": 0}
    )
    return {"is_saved": bool(is_saved)}

@api_router.get("/saved/user")
async def get_saved_projects(current_user: dict = Depends(get_current_user)):
    saved = await db.saved_posts.find({"user_id": current_user['id']}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    project_ids = [s['project_id'] for s in saved]
    
    projects = await db.projects.find({"id": {"$in": project_ids}}, {"_id": 0}).to_list(1000)
    return projects

# ============== MESSAGES ==============

@api_router.post("/messages")
async def send_message(message_data: MessageCreate, current_user: dict = Depends(get_current_user)):
    message = Message(
        sender_id=current_user['id'],
        receiver_id=message_data.receiver_id,
        content=message_data.content,
        content_type=message_data.content_type
    )
    
    doc = message.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.messages.insert_one(doc)
    
    return message

@api_router.get("/messages/{user_id}")
async def get_conversation(user_id: str, current_user: dict = Depends(get_current_user)):
    messages = await db.messages.find(
        {
            "$or": [
                {"sender_id": current_user['id'], "receiver_id": user_id},
                {"sender_id": user_id, "receiver_id": current_user['id']}
            ]
        },
        {"_id": 0}
    ).sort("created_at", 1).to_list(1000)
    
    # Mark as read
    await db.messages.update_many(
        {"sender_id": user_id, "receiver_id": current_user['id'], "is_read": False},
        {"$set": {"is_read": True}}
    )
    
    return messages

@api_router.get("/messages/conversations/list")
async def get_conversations(current_user: dict = Depends(get_current_user)):
    # Get all unique users I've chatted with
    messages = await db.messages.find(
        {
            "$or": [
                {"sender_id": current_user['id']},
                {"receiver_id": current_user['id']}
            ]
        },
        {"_id": 0}
    ).sort("created_at", -1).to_list(1000)
    
    user_ids = set()
    for msg in messages:
        if msg['sender_id'] != current_user['id']:
            user_ids.add(msg['sender_id'])
        if msg['receiver_id'] != current_user['id']:
            user_ids.add(msg['receiver_id'])
    
    users = await db.users.find(
        {"id": {"$in": list(user_ids)}},
        {"_id": 0, "password_hash": 0}
    ).to_list(1000)
    
    return users

# ============== NOTIFICATIONS ==============

@api_router.get("/notifications")
async def get_notifications(current_user: dict = Depends(get_current_user)):
    notifications = await db.notifications.find(
        {"user_id": current_user['id']},
        {"_id": 0}
    ).sort("created_at", -1).limit(50).to_list(50)
    return notifications

@api_router.put("/notifications/read")
async def mark_notifications_read(current_user: dict = Depends(get_current_user)):
    await db.notifications.update_many(
        {"user_id": current_user['id'], "is_read": False},
        {"$set": {"is_read": True}}
    )
    return {"message": "Marked as read"}

# ============== AI FEATURES ==============

@api_router.post("/ai/generate-image")
async def generate_image(request: ImageGenerateRequest, current_user: dict = Depends(get_current_user)):
    try:
        images = await image_gen.generate_images(
            prompt=request.prompt,
            model="imagen-3.0-generate-002",
            number_of_images=1
        )
        
        if not images:
            raise HTTPException(status_code=500, detail="Image generation failed")
        
        # Add watermark
        watermarked_image = add_watermark(images[0])
        
        # Save to database
        gen_image = GeneratedImage(
            user_id=current_user['id'],
            prompt=request.prompt,
            image_data=watermarked_image
        )
        
        doc = gen_image.model_dump()
        doc['created_at'] = doc['created_at'].isoformat()
        await db.generated_images.insert_one(doc)
        
        return {"image_data": watermarked_image, "id": gen_image.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Image generation error: {str(e)}")

@api_router.get("/ai/generated-images")
async def get_generated_images(current_user: dict = Depends(get_current_user)):
    images = await db.generated_images.find(
        {"user_id": current_user['id']},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    return images

@api_router.post("/ai/assistant")
async def ai_assistant(message: AIAssistantMessage, current_user: dict = Depends(get_current_user)):
    """AI assistant for platform help"""
    
    # Safety check
    harmful_keywords = ['hack', 'password', 'exploit', 'attack', 'breach', 'steal']
    if any(keyword in message.message.lower() for keyword in harmful_keywords):
        return {"response": "Sorry, I cannot help you with that."}
    
    system_prompt = """You are a helpful assistant for Design's platform. You help users understand how to:
- Upload and manage design projects (CorelDRAW, Photoshop, Illustrator, PNG, JPG files)
- Search for users and projects
- Use the AI image generator
- Send messages to other designers
- Manage their profile and settings
- Follow users and interact with posts (like, comment, save)

You understand both Hindi and English. Be polite, concise, and helpful. Never provide passwords or sensitive information."""
    
    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=f"assistant_{current_user['id']}",
        system_message=system_prompt
    ).with_model("openai", "gpt-5")
    
    user_message = UserMessage(text=message.message)
    response = await chat.send_message(user_message)
    
    return {"response": response}

# ============== ROOT ==============

@api_router.get("/")
async def root():
    return {"message": "Design's API"}

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()